# Simple-Scrollable-Website
A simple scrollable website just for storing and representing data ( pictures are also added ) 







I've also attached a zip file where I've used this template I shared with you guys :)
Hope its nice because it is my first try lol 
